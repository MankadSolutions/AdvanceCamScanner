
    # Android native OpenCV integration (instructions)

This project includes a Dart-side platform channel scaffold: MethodChannel('scanfast/edge_detection').

To implement real OpenCV-based edge detection on Android:

1. Add OpenCV Android SDK to your project (as module or using Maven if available).
2. Create a Kotlin class in `android/app/src/main/kotlin/.../EdgeDetectionPlugin.kt`:

```kotlin
package com.example.scanfast_advanced

import android.graphics.BitmapFactory
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

class EdgeDetectionPlugin: FlutterPlugin, MethodChannel.MethodCallHandler {
  private lateinit var channel : MethodChannel
  override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
    channel = MethodChannel(binding.binaryMessenger, "scanfast/edge_detection")
    channel.setMethodCallHandler(this)
  }

  override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
    if (call.method == "detectAndCrop") {
      val path = call.argument<String>("path")
      // TODO: load bitmap, run OpenCV (Canny -> findContours -> approxPolyDP -> perspective transform)
      // For now return the same path to indicate success
      result.success(path)
    } else {
      result.notImplemented()
    }
  }

  override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
    channel.setMethodCallHandler(null)
  }
}
```

3. Implement OpenCV native code and add JNI layer if needed. Use `org.opencv.core` utilities to perform the detection.
4. Ensure you register plugin in AndroidManifest or use Flutter embedding v2 (automatic registration).

This approach keeps heavy image processing native and fast.
