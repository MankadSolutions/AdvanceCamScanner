
    # Privacy Policy — ScanFast Advanced

**Last updated:** Oct 3, 2025

## 1. Introduction
ScanFast Advanced ("we", "us", "our") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our mobile application.

## 2. Data We Collect
- **Camera & Photos**: Images you capture or import to create documents. These are stored locally unless you enable Cloud Sync.
- **Device Permissions**: Camera, storage access for saving and reading files.
- **Optional**: If you enable cloud features, we may store documents in your chosen cloud provider.

## 3. How We Use Data
- To provide scanning, OCR, PDF export, and sharing functionality.
- To improve the app (anonymous crash reports if enabled).

## 4. On-device Processing
By default, all image processing (edge detection, filters) and OCR run on-device. We will not upload documents to our servers unless you explicitly enable cloud sync.

## 5. Third-party Services
We may use third-party services for analytics, crash reporting, ads (AdMob), and cloud storage. Refer to their privacy policies for more information.

## 6. Contact
For questions, contact: privacy@yourdomain.com
