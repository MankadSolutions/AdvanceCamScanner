
# ScanFast Advanced — Flutter Starter
This is a starter skeleton for an advanced CamScanner-style app built with Flutter.

## What is included
- Polished UI screens: Home, Camera, Document List, Viewer placeholders
- Camera capture flow with file saving
- PDF export service (basic)
- Image filters & crop placeholders
- Hive local storage placeholder for documents
- Clear TODOs for adding OCR, cloud sync, and edge-detection algorithms

## How to use
1. Create a new Flutter project (or use `flutter create scanfast_advanced`).
2. Replace the generated `lib/` folder with the contents of this archive's `lib/`.
3. Replace `pubspec.yaml` dependencies with the one provided here and run `flutter pub get`.
4. Configure Android & iOS permissions for camera and storage (see TODOs in code).
5. Run the app: `flutter run` (an Android emulator or device with camera is recommended).

## Files of interest
- `lib/main.dart` — app entry, routing & theme
- `lib/screens/camera_screen.dart` — camera capture & preview
- `lib/screens/document_list_screen.dart` — document management UI
- `lib/services/pdf_service.dart` — generate PDF from image list
- `lib/widgets/document_card.dart` — UI component for documents

## Note
This is a starter. Advanced features like automatic edge detection, on-device optimized OCR, cloud sync (Firebase), and production-ready billing/ad integration are indicated as TODOs and templates in the code.
