
import 'package:flutter/material.dart';
import 'screens/document_list_screen.dart';
import 'screens/camera_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ScanFastApp());
}

class ScanFastApp extends StatelessWidget {
  const ScanFastApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ScanFast Advanced',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/',
      routes: {
        '/': (_) => const DocumentListScreen(),
        '/camera': (_) => const CameraScreen(),
      },
    );
  }
}
