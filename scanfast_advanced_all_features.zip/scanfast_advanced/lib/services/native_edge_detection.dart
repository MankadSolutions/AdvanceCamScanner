
// Native Edge Detection Platform Channel (Dart side)
// This creates a method channel to call native code (Android/iOS) which performs OpenCV-based edge detection.
import 'dart:async';
import 'package:flutter/services.dart';

class NativeEdgeDetection {
  static const MethodChannel _channel = MethodChannel('scanfast/edge_detection');

  /// Returns path to the processed (cropped & perspective-corrected) image.
  static Future<String?> detectAndCrop(String imagePath) async {
    try {
      final result = await _channel.invokeMethod<String>('detectAndCrop', {'path': imagePath});
      return result;
    } on PlatformException catch (e) {
      print('Native edge detection error: \$e');
      return null;
    }
  }
}
