
import 'dart:io';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

class PdfService {
  /// Create a PDF from a list of image file paths.
  static Future<String?> createPdfFromImages(List<String> imagePaths, {String? fileName}) async {
    try {
      final pdf = pw.Document();
      for (final imgPath in imagePaths) {
        final image = pw.MemoryImage(File(imgPath).readAsBytesSync());
        pdf.addPage(pw.Page(build: (pw.Context context) {
          return pw.Center(child: pw.Image(image, fit: pw.BoxFit.contain));
        }));
      }
      final dir = await getApplicationDocumentsDirectory();
      final outName = fileName ?? 'scan_pdf_\${DateTime.now().millisecondsSinceEpoch}.pdf';
      final outPath = p.join(dir.path, outName);
      final file = File(outPath);
      await file.writeAsBytes(await pdf.save());
      return outPath;
    } catch (e) {
      print('PDF create error: \$e');
      return null;
    }
  }

  /// Print or share PDF (using printing package)
  static Future<void> previewPdf(String pdfPath) async {
    await Printing.layoutPdf(onLayout: (_) => File(pdfPath).readAsBytesSync());
  }
}
