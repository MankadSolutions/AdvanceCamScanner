
import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdsService {
  static Future<InitializationStatus> init() async {
    return await MobileAds.instance.initialize();
  }

  static BannerAd createBannerAd({required String adUnitId}) {
    return BannerAd(
      adUnitId: adUnitId,
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(),
    );
  }
}
