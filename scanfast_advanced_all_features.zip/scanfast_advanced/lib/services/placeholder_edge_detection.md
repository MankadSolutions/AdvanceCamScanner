
# Edge Detection — Integration Notes
This file describes options to implement automatic edge detection / perspective transform:

1. **OpenCV (native)**:
   - Use OpenCV on native Android (Kotlin) and iOS (Swift) to perform Canny edge detection and findContours.
   - Communicate with Flutter via platform channels.
2. **On-device ML models**:
   - Use a lightweight ML model trained to predict document corners.
3. **Dart libraries**:
   - Pure Dart options are limited; consider using native code for production-quality detection.

Steps (high level):
- Capture image → convert to grayscale → apply Gaussian blur → Canny edges → find contours → approximate polygon → select biggest 4-corner polygon → apply perspective transform.
