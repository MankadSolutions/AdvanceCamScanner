
    # Play Store Release Checklist

1. App bundle / APK generated and signed.
2. Privacy policy hosted on a reachable HTTPS URL and linked in store listing.
3. Correct permissions listed in AndroidManifest with in-context permission rationale.
4. Implemented Play Billing for subscriptions/one-time purchases (if applicable).
5. No malware, no obfuscated background data collection.
6. Appropriate target API level (check latest Play Console requirements).
7. High-quality screenshots and promo video prepared.
8. Complete content rating questionnaire.
9. Test with internal testing track before public release.
10. Prepare support email and contact info.
