
Feature implementation notes & manual steps (must perform locally):

1. Firebase:
   - Run `flutterfire configure` on your machine to create `lib/firebase_options.dart` and register Android/iOS apps.
   - Add SHA-1 keys for Android in Firebase console for auth and dynamic links.
2. Google ML Kit OCR:
   - Ensure `google_mlkit_text_recognition` is added to pubspec (done).
   - Follow platform-specific installation steps in the package docs (AndroidX, iOS pods).
3. OpenCV on Android:
   - Add OpenCV SDK to android project (module or native libs) and implement processing in `EdgeDetectionPlugin.kt`.
4. Play Billing:
   - Configure products/subscriptions in Google Play Console and test with license testers.
5. AdMob:
   - Create AdMob app and ad units, replace ad unit IDs in code before release.
