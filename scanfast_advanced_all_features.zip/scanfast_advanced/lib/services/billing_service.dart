
import 'dart:async';
import 'package:in_app_purchase/in_app_purchase.dart';

class BillingService {
  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _sub;

  void init() {
    final purchaseUpdated = _iap.purchaseStream;
    _sub = purchaseUpdated.listen((purchases) {
      // handle purchase updates
      for (var p in purchases) {
        // verify & deliver product
        print('Purchase update: \${p.productID} - \${p.status}');
      }
    }, onDone: () => _sub?.cancel(), onError: (e) => print('Purchase stream error: \$e'));
  }

  Future<void> buy(String productId) async {
    final details = ProductDetails(
      id: productId,
      title: '',
      description: '',
      price: '',
    );
    // Real flow: queryProductDetails, then call buyNonConsumable or buyConsumable
  }

  void dispose() {
    _sub?.cancel();
  }
}
