
# OCR Integration TODO
Recommended: Google ML Kit (google_mlkit_text_recognition) or Tesseract for on-device OCR.

Steps:
1. Add dependency and follow setup guides for Android & iOS.
2. Convert image to input format (InputImage) and run text recognizer.
3. Save text output and allow user to copy / search within app.

Privacy: Keep OCR processing on-device unless user explicitly enables cloud OCR.
