
import 'dart:io';
import 'package:flutter/material.dart';
import '../widgets/document_card.dart';

class DocumentListScreen extends StatefulWidget {
  const DocumentListScreen({Key? key}) : super(key: key);

  @override
  State<DocumentListScreen> createState() => _DocumentListScreenState();
}

class _DocumentListScreenState extends State<DocumentListScreen> {
  // Placeholder list; later connect to Hive / local storage
  final List<Map<String, dynamic>> documents = [
    {'title': 'Receipt - July', 'pages': 2, 'path': null},
    {'title': 'Agreement', 'pages': 1, 'path': null},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ScanFast — Documents'),
        actions: [
          IconButton(
            tooltip: 'Import / Settings',
            onPressed: () {},
            icon: const Icon(Icons.settings_outlined),
          )
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            ElevatedButton.icon(
              icon: const Icon(Icons.camera_alt),
              label: const Text('Scan Document'),
              onPressed: () => Navigator.pushNamed(context, '/camera'),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: documents.length,
                itemBuilder: (context, i) {
                  final doc = documents[i];
                  return DocumentCard(
                    title: doc['title'],
                    pages: doc['pages'],
                    onTap: () {
                      // TODO: open document viewer
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Open "\${doc['title']}"')),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
