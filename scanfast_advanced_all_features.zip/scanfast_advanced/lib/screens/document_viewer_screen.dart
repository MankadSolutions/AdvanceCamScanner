
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../services/pdf_service.dart';
import 'package:image_cropper/image_cropper.dart';

class DocumentViewerScreen extends StatefulWidget {
  final List<String> pages;
  final String title;

  const DocumentViewerScreen({Key? key, required this.pages, required this.title}) : super(key: key);

  @override
  State<DocumentViewerScreen> createState() => _DocumentViewerScreenState();
}

class _DocumentViewerScreenState extends State<DocumentViewerScreen> {
  int current = 0;

  Future<void> _cropImage(int index) async {
    final path = widget.pages[index];
    final cropped = await ImageCropper().cropImage(sourcePath: path, compressQuality: 90);
    if (cropped != null) {
      setState(() {
        widget.pages[index] = cropped.path;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            onPressed: () async {
              final pdfPath = await PdfService.createPdfFromImages(widget.pages);
              if (pdfPath != null) {
                await PdfService.previewPdf(pdfPath);
              }
            },
          ),
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: () async {
              final pdfPath = await PdfService.createPdfFromImages(widget.pages);
              if (pdfPath != null) {
                await Share.shareXFiles([XFile(pdfPath)], text: widget.title);
              }
            },
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: PageView.builder(
              itemCount: widget.pages.length,
              onPageChanged: (i) => setState(() => current = i),
              itemBuilder: (context, i) {
                return InteractiveViewer(
                  child: Image.file(File(widget.pages[i]), fit: BoxFit.contain),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('${current + 1} / ${widget.pages.length}'),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.crop),
                      onPressed: () => _cropImage(current),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () {
                        setState(() {
                          widget.pages.removeAt(current);
                          if (current >= widget.pages.length) current = widget.pages.length - 1;
                        });
                      },
                    )
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
