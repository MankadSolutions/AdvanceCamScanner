
import 'package:flutter/material.dart';
import 'dart:io';
import '../screens/document_viewer_screen.dart';

class MultiPageCreator extends StatefulWidget {
  final List<String> pages;
  const MultiPageCreator({Key? key, required this.pages}) : super(key: key);

  @override
  State<MultiPageCreator> createState() => _MultiPageCreatorState();
}

class _MultiPageCreatorState extends State<MultiPageCreator> {
  final List<String> tempPages = [];

  @override
  void initState() {
    super.initState();
    tempPages.addAll(widget.pages);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Create Document'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => DocumentViewerScreen(pages: tempPages, title: 'New Document')));
            },
            child: const Text('Preview', style: TextStyle(color: Colors.white)),
          )
        ],
      ),
      body: ListView.builder(
        itemCount: tempPages.length,
        itemBuilder: (context, i) {
          final p = tempPages[i];
          return ListTile(
            leading: Image.file(File(p), width: 56, height: 56, fit: BoxFit.cover),
            title: Text('Page \${i + 1}'),
            trailing: IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () => setState(() => tempPages.removeAt(i)),
            ),
          );
        },
      ),
    );
  }
}
