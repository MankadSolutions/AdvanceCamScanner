
import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

// NOTE: This screen implements camera capture and saving to a local file.
// For advanced edge detection and automatic crop, integrate an algorithm (OpenCV / ML models)

List<CameraDescription> cameras = [];

class CameraScreen extends StatefulWidget {
  const CameraScreen({Key? key}) : super(key: key);

  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  CameraController? controller;
  bool isReady = false;

  @override
  void initState() {
    super.initState();
    _initCamera();
  }

  Future<void> _initCamera() async {
    try {
      cameras = await availableCameras();
      if (cameras.isNotEmpty) {
        controller = CameraController(cameras[0], ResolutionPreset.high, enableAudio: false);
        await controller!.initialize();
        if (!mounted) return;
        setState(() => isReady = true);
      }
    } catch (e) {
      debugPrint('Camera init error: \$e');
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  Future<String?> _takePicture() async {
    if (controller == null || !controller!.value.isInitialized) return null;
    try {
      final XFile raw = await controller!.takePicture();
      final Directory appDocDir = await getApplicationDocumentsDirectory();
      final String fileName = 'scan_\${DateTime.now().millisecondsSinceEpoch}.jpg';
      final String savedPath = p.join(appDocDir.path, fileName);
      await raw.saveTo(savedPath);
      return savedPath;
    } catch (e) {
      debugPrint('Capture error: \$e');
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan — Camera')),
      body: Center(
        child: isReady && controller != null
            ? Stack(
                children: [
                  CameraPreview(controller!),
                  Positioned(
                    bottom: 24,
                    left: 0,
                    right: 0,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        FloatingActionButton(
                          heroTag: 'capture',
                          onPressed: () async {
                            final path = await _takePicture();
                            if (path != null) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Saved: \$path')),
                              );
                              // TODO: Run edge detection & crop, then add to temp document pages
                            }
                          },
                          child: const Icon(Icons.camera_alt),
                        ),
                      ],
                    ),
                  )
                ],
              )
            : const Text('Loading camera...'),
      ),
    );
  }
}
